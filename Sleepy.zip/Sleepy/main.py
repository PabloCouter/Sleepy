from tkinter import *
from os import system as cmd

root = Tk()
root.title("Sleppy")
root.geometry("350x300")


def sleep():
    if len(et_hour.get()) > 0:
        hour = int(et_hour.get())
    else:
        hour = 0

    if len(et_minute.get()) > 0:
        minute = int(et_minute.get())
    else:
        minute = 0

    if len(et_second.get()) > 0:
        second = int(et_second.get())
    else:
        second = 0

    total = ((hour*3600) + (minute*60) + second)
    cmd('shutdown -s -t {}' .format(total))

    et_hour.select_clear()
    et_minute.select_clear()
    et_second.select_clear()


def wakeup():
    cmd('shutdown -a')


main_frame = Frame(root)
main_frame.pack()

# Title
title_frame = Frame(main_frame)
title_frame.pack()

lb_tile = Label(title_frame, text='Sleepy', justify=CENTER)
lb_tile.config(font=('Bahnschrift', 30))
lb_tile.pack(pady=10)

# Time
time_frame = Frame(main_frame)
time_frame.pack()

#       Hour
hr_frame = Frame(time_frame)
hr_frame.pack()
lb_hour = Label(hr_frame, text='Horas')
lb_hour.pack()
et_hour = Entry(hr_frame, bd=3)
et_hour.pack()

#       Minute
mn_frame = Frame(time_frame)
mn_frame.pack()
lb_minute = Label(mn_frame, text='Minutos')
lb_minute.pack()
et_minute = Entry(mn_frame, bd=3)
et_minute.pack()

#       Second
sc_frame = Frame(time_frame, )
sc_frame.pack()
lb_second = Label(sc_frame, text='Segundos')
lb_second.pack()
et_second = Entry(sc_frame, bd=3)
et_second.pack()

# Buttons
buttons_frame = Frame(main_frame)
buttons_frame.pack(pady=20)
sleep_button = Button(buttons_frame, text='Programar', width=10, command=sleep)
sleep_button.config(font=20)
sleep_button.pack(side=LEFT)

cancel_button = Button(buttons_frame, text='Cancelar', width=10, command=wakeup)
cancel_button.config(font=20)
cancel_button.pack()

root.iconbitmap('power.ico')
root.mainloop()
